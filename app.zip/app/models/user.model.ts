export class User {
	userid: number;
	email: string;
	fullName: string;
	password: string;
}