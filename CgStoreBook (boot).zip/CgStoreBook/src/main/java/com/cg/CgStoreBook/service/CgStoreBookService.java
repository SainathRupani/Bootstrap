package com.cg.CgStoreBook.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.CgStoreBook.entities.User;

public interface CgStoreBookService {

	public User newUser(User user);

	public List<User> listAll();

	public void deleteUser(int userid);

	
	/* public User createUser(User user); */

	

}
