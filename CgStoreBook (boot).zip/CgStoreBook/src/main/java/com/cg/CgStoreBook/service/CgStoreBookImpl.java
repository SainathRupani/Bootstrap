package com.cg.CgStoreBook.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.CgStoreBook.dao.CgStoreBookDao;
import com.cg.CgStoreBook.entities.User;


@Transactional
@Service("cgBookStoreService")
public class CgStoreBookImpl implements CgStoreBookService{
	
	@Autowired
	CgStoreBookDao cgStoreBookDao;

	@Override
	public User newUser(User user) {
		
		return cgStoreBookDao.save(user);
	}

	@Override
	public List<User> listAll() {
		
		return cgStoreBookDao.findAll() ;
	}

	@Override
	public void deleteUser(int userid) {
		cgStoreBookDao.deleteById(userid);
		
	}

	

}
