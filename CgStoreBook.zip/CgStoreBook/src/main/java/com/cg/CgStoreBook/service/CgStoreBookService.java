package com.cg.CgStoreBook.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.CgStoreBook.entities.User;

public interface CgStoreBookService {

	public User newUser(User user);

	
	/* public User createUser(User user); */

	

}
