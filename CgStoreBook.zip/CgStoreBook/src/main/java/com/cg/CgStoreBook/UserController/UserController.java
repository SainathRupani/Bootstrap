package com.cg.CgStoreBook.UserController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CgStoreBook.entities.User;
import com.cg.CgStoreBook.service.CgStoreBookService;

@RestController
@RequestMapping("/rest")
public class UserController {

	@Autowired
	CgStoreBookService  cgBookStoreService; 

	
	@RequestMapping("/index")
	public String index(Model model) {
	
		System.out.println("sdfdsvgasdgadfgasdf");
		return "dsfkjaesghfkurewgfghfjaewghfrgf";
	}
	
	@RequestMapping("/new")
	public User newUser() {
		User user=new User("sai@g.com","sainath","123456");
		cgBookStoreService.newUser(user);
		return user;
	}
	
	
	
	
	
}


