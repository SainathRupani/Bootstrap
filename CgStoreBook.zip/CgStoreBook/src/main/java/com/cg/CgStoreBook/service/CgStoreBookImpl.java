package com.cg.CgStoreBook.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.CgStoreBook.dao.CgStoreBookDao;
import com.cg.CgStoreBook.entities.User;


@Transactional
@Service("cgBookStoreService")
public class CgStoreBookImpl implements CgStoreBookService{
	
	@Autowired
	CgStoreBookDao cgStoreBookDao;

	@Override
	public User newUser(User user) {
		// TODO Auto-generated method stub
		return cgStoreBookDao.save(user);
	}

	/*
	 * @Override public User createUser(User user) {
	 * 
	 * return null; }
	 */

}
