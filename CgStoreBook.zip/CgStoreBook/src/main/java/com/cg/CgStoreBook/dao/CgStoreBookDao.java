package com.cg.CgStoreBook.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.CgStoreBook.entities.User;

@Repository("cgStoreBookDao")
public interface CgStoreBookDao extends JpaRepository<User, Integer>{
		User save(User user);
}

