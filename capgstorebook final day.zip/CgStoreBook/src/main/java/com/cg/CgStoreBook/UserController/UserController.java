package com.cg.CgStoreBook.UserController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.CgStoreBook.entities.User;
import com.cg.CgStoreBook.service.CgStoreBookService;

@RestController
@RequestMapping("/rest")
public class UserController {

	@Autowired
	CgStoreBookService  cgBookStoreService; 

	
	@RequestMapping("/index")
	public String index(Model model) {
	
		System.out.println("Welcome");
		return "WELCOME";
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method=RequestMethod.POST,value="/new")
			public User newUser(@RequestBody User user) {
				cgBookStoreService.newUser(user);
		         return user;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method=RequestMethod.GET,value="/list")
	         public List<User> listAll(){
		           return cgBookStoreService.listAll();
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method=RequestMethod.DELETE,value="/deleteUser/{userid}")
	public void deleteUser(@PathVariable int userid) {
		cgBookStoreService.deleteUser(userid);
		
		
	}
	
	
	
}


