package com.cg.CgStoreBook.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Table(name="StoreBook")
@Component
public class User {
	 
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private int userid;
	@NotNull
	@Email
	@Size(min=10,max=64)
	private String email;
	@NotNull
	@Size(min=8,max=30)
	private String fullName;
	@NotNull
	@Size(min=8,max=16)
	
	private String password;
	
	
	public User() {
		
		// TODO Auto-generated constructor stub
	}

	

	public User(String email, String fullName, String password) {
		super();
		this.email = email;
		this.fullName = fullName;
		this.password = password;
	}



	public int getUserid() {
		return userid;
	}


	public void setUserid(int userid) {
		this.userid = userid;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "User [userid=" + userid + ", email=" + email + ", fullName=" + fullName + ", password=" + password
				+ "]";
	}
	
	
	
	

}
